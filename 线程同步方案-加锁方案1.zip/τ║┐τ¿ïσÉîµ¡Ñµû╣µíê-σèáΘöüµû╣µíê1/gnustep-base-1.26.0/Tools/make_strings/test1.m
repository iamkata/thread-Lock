
_(@"foo") _ ( @"foo2" /* test */ )

"_()"

"  \" _(foo) \" /* comment "

_ // test
(@ /* comment " */ "test"
@
" test2"
)

NSLocalizedString(@"Information", @"")
